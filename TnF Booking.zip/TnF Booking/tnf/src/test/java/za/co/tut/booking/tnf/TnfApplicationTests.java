package za.co.tut.booking.tnf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TnfApplicationTests {

	@Test
	void contextLoads() {
	}

}
